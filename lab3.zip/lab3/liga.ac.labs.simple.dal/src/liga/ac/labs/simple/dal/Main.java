package liga.ac.labs.simple.dal;

public class Main {
	
	public static void main(String[] argv){
		
		Requirements r1 = new Requirements("Alexandra", "student");
		
		Requirements r2 = new Requirements("Oana", "student");
		
		Requirements r3 = new Requirements("Cristina", "student");
		
	 //	PersistenceUtility.getInstance().create(r1);
	 	
	 //	PersistenceUtility.getInstance().create(r2);
	 	
	 	//PersistenceUtility.getInstance().create(r3);
	 	
	 	java.util.List<Requirements> requirements = PersistenceUtility.getInstance().read();
	 	
	 	for(Requirements r: requirements)
	 		System.out.println(r);
	}
}
