package liga.ac.labs.simple.dal;

import java.awt.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistenceUtility {			//singleton

	private static PersistenceUtility instance;
	
	private EntityManagerFactory emf;
	
	private EntityManager em;
	
	private PersistenceUtility() {
		
		this.emf = Persistence.createEntityManagerFactory("$objectdb/db/requirements.odb");
	}
	
	public static PersistenceUtility getInstance(){
		
		if(instance == null)
		{
			instance = new PersistenceUtility();
			
			instance.em = instance.emf.createEntityManager();
			
			return instance;
		}
		else
			return instance;
	}
	
	public void create(Requirements r) {
		
		em.getTransaction().begin();
		
		em.persist(r);
		
		em.getTransaction().commit();
		
		em.close();
	}
	
	public java.util.List<Requirements> read() {
		
		java.util.List<Requirements> requirements = em.createQuery("SELECT r FROM Requirements r").getResultList();
		
		return requirements;
	}
} 
