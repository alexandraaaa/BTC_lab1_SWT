package liga.ac.labs.simple.dal;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Requirements {

	@Id	
	@GeneratedValue		//cheie generata automat
	private int ID;
	@Basic
	private String name;
	@Basic
	private String description;

	public Requirements(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public int getID() {
		return ID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString() {
		
		return name + " " + description;
	}
}
