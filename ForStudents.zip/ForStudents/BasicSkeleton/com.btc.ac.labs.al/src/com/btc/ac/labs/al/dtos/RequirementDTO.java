package com.btc.ac.labs.al.dtos;

public interface RequirementDTO {
	
	long getId();

	String getName();
	
	String getDescription();
}
