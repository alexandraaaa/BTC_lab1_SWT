package com.btc.ac.labs.al.factories;

import com.btc.ac.labs.al.dtos.RequirementDTO;

public interface RequirementDTOFactory {
	
	RequirementDTO create(String name, String description);
	
	RequirementDTO create(long id, String name, String description);
	
}
