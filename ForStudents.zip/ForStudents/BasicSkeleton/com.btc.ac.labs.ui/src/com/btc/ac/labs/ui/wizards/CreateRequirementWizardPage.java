package com.btc.ac.labs.ui.wizards;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

@Creatable
public class CreateRequirementWizardPage extends WizardPage {

	private Text txtName;
	private Text txtDescription;
	
	public CreateRequirementWizardPage() {
		super("Create New Requirement Page");
	}

	public String getName() {
		return txtName.getText();
	}
	
	public String getDescription() {
		return txtDescription.getText();
	}

	@Override
	public void createControl(Composite parent) {
		parent.setLayout(new GridLayout());

		GridData dataAllFill = new GridData();
		dataAllFill.horizontalAlignment = SWT.FILL;
		dataAllFill.grabExcessHorizontalSpace = true;
		dataAllFill.verticalAlignment = SWT.FILL;
		dataAllFill.grabExcessVerticalSpace = true;

		GridData dataHorisontalFill = new GridData();
		dataHorisontalFill.horizontalAlignment = SWT.FILL;
		dataHorisontalFill.grabExcessHorizontalSpace = true;

		Group group = new Group(parent, SWT.NONE);
		group.setText("Requirement details");
		group.setLayout(new GridLayout());
		group.setLayoutData(dataAllFill);

		Label lblName = new Label(group, SWT.NONE);
		lblName.setText("Name:");

		
		txtName = new Text(group, SWT.BORDER);
		txtName.setEditable(true);
		txtName.setLayoutData(dataHorisontalFill);
		txtName.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				checkPageComplete();
			}
		});

		Label lblDescription = new Label(group, SWT.NONE);
		lblDescription.setText("Description:");

		txtDescription = new Text(group, SWT.BORDER);
		txtDescription.setEditable(true);
		txtDescription.setLayoutData(dataHorisontalFill);
		txtDescription.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				checkPageComplete();
			}
		});

		setControl(parent);
		setPageComplete(false);
	}

	private void checkPageComplete() {
		if (txtName.getText() == "")
			return;
		if (txtDescription.getText() == "")
			return;
		setPageComplete(true);
	}
}
