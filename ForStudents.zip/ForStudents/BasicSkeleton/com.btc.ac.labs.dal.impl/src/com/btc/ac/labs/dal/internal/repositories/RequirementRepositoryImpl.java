package com.btc.ac.labs.dal.internal.repositories;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.osgi.service.component.annotations.Component;

import com.btc.ac.labs.bl.dmos.RequirementDMO;
import com.btc.ac.labs.bl.internal.dmos.RequirementDMOImpl;
import com.btc.ac.labs.dal.internal.dmos.Requirement;
import com.btc.ac.labs.dal.internal.utility.PersistenceUtility;
import com.btc.ac.labs.dal.repositories.RequirementRepository;

@Component
public class RequirementRepositoryImpl implements RequirementRepository{

	@Override
	public void create(RequirementDMO dmo) {
		
		PersistenceUtility.getInstance().create(convertDMO(dmo));
	}

	@Override
	public void update(RequirementDMO dmo) {
		PersistenceUtility.getInstance().update(convertDMO(dmo));
	}

	@Override
	public void remove(long id) {
		PersistenceUtility.getInstance().remove(id);
	}

	@Override
	public RequirementDMO get(long id) {
		return convertRequirement(PersistenceUtility.getInstance().get(id));
	}

	@Override
	public List<RequirementDMO> getAll() {
		return PersistenceUtility.getInstance().getAll().stream().map(r -> convertRequirement(r)).collect(Collectors.toList());
	}

	@Override
	public List<RequirementDMO> getMatching(String match) {
		return PersistenceUtility.getInstance().getMatching(match).stream().map(r -> convertRequirement(r)).collect(Collectors.toList());
	}

	private Requirement convertDMO(RequirementDMO dmo) {
		return new Requirement(dmo);
	}
	
	private RequirementDMO convertRequirement(Requirement requirement) {
		return new RequirementDMOImpl(requirement.getId(), requirement.getName(), requirement.getDescription());
	}
}
