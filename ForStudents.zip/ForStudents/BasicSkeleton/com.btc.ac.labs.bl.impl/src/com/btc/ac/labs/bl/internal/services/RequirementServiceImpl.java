package com.btc.ac.labs.bl.internal.services;

import java.util.List;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.ac.labs.bl.dmos.RequirementDMO;
import com.btc.ac.labs.bl.internal.dmos.RequirementDMOImpl;
import com.btc.ac.labs.bl.services.RequirementService;
import com.btc.ac.labs.dal.repositories.RequirementRepository;

@Component
public class RequirementServiceImpl implements RequirementService {
	private RequirementRepository requirementRepository;

	@Override
	public void saveRequirement(String name, String description) {
		RequirementDMO dmo = new RequirementDMOImpl(name, description);
		requirementRepository.create(dmo);
	}

	@Override
	public void updateRequirement(RequirementDMO requirementDMO) {
		requirementRepository.update(requirementDMO);
	}

	@Override
	public void removeRequirement(long id) {
		requirementRepository.remove(id);
	}

	@Override
	public List<RequirementDMO> getAll() {
		return requirementRepository.getAll();
	}

	@Override
	public RequirementDMO get(long id) {
		return requirementRepository.get(id);
	}

	@Override
	public List<RequirementDMO> getMatching(String match) {
		return requirementRepository.getMatching(match);
	}

	@Reference
	public void setRequirementRepository(RequirementRepository repository) {
		this.requirementRepository = repository;
	}
}
