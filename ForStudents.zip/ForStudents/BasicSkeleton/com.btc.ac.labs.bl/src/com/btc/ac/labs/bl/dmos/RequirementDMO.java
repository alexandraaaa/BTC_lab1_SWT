package com.btc.ac.labs.bl.dmos;

public interface RequirementDMO {
	long getId();

	String getName();
	
	void setName(String name);
	
	String getDescription();
	
	void setDescription(String name);
}
