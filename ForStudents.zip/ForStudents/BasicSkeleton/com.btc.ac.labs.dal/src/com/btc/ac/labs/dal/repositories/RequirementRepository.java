package com.btc.ac.labs.dal.repositories;

import java.util.List;

import com.btc.ac.labs.bl.dmos.RequirementDMO;

public interface RequirementRepository {
	public void create(RequirementDMO dmo);
	public void update(RequirementDMO dmo);
	public void remove(long id);
	public RequirementDMO get(long id);
	public List<RequirementDMO> getAll();
	public List<RequirementDMO> getMatching(String match);
}
