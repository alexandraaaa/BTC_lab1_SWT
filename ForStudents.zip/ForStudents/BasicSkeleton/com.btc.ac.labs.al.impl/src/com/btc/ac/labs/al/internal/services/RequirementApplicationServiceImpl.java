package com.btc.ac.labs.al.internal.services;

import java.util.List;
import java.util.stream.Collectors;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.al.internal.converters.RequirementConverter;
import com.btc.ac.labs.al.services.RequirementApplicationService;
import com.btc.ac.labs.bl.dmos.RequirementDMO;
import com.btc.ac.labs.bl.services.RequirementService;

@Component
public class RequirementApplicationServiceImpl implements RequirementApplicationService{
	private RequirementService requirementService;
	private RequirementConverter requirementFactory;
	
	@Override
	public void saveRequirement(String name, String description) {
		requirementService.saveRequirement(name, description);
		
	}

	@Override
	public RequirementDTO updateRequirement(RequirementDTO requirementDTO) {
		RequirementDMO dmo = requirementFactory.createRequirementDMO(requirementDTO);
		requirementService.updateRequirement(dmo);
		RequirementDTO dto = requirementFactory.createRequirementDTO(requirementService.get(dmo.getId()));
		return dto;
	}

	@Override
	public void removeRequirement(long id) {
		requirementService.removeRequirement(id);
	}
	
	@Override
	public List<RequirementDTO> getAll() {
		return requirementService.getAll().stream().map(r -> requirementFactory.createRequirementDTO(r)).collect(Collectors.toList());
	}

	@Override
	public List<RequirementDTO> getMatching(String match) {
		return requirementService.getMatching(match).stream().map(r -> requirementFactory.createRequirementDTO(r)).collect(Collectors.toList());
	}
	
	@Reference
	public void setRequirementService(RequirementService service) {
		this.requirementService = service;
	}
	
	@Reference
	public void setRequirementFactory(RequirementConverter factory) {
		this.requirementFactory = factory;
	}

}
