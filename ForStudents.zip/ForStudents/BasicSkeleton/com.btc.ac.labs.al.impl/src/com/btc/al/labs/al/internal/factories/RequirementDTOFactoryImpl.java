package com.btc.al.labs.al.internal.factories;

import org.osgi.service.component.annotations.Component;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.al.factories.RequirementDTOFactory;
import com.btc.ac.labs.al.internal.dtos.RequirementDTOImpl;

@Component
public class RequirementDTOFactoryImpl implements RequirementDTOFactory{

	@Override
	public RequirementDTO create(String name, String description) {
		return new RequirementDTOImpl(name, description);
	}

	@Override
	public RequirementDTO create(long id, String name, String description) {
		// TODO Auto-generated method stub
		return new RequirementDTOImpl(id, name, description);
	}

}
