package com.btc.bl.dmos;

public interface Requirement {

	String getName();
	String getDescription();
}
