package com.btc.bl.services;

import java.util.List;

import com.btc.bl.dmos.Requirement;

public interface RequirementService {

	void create(String name, String description);
	
	List<Requirement> getAll();
}
