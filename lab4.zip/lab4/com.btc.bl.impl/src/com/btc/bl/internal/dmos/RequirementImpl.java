package com.btc.bl.internal.dmos;

import com.btc.bl.dmos.Requirement;

public class RequirementImpl implements Requirement {

	private String name;
	private String description;
	
	public RequirementImpl(String name, String description) {
		this.name = name;
		this.description = description;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return description;
	}

}
