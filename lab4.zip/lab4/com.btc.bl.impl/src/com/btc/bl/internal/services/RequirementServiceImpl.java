package com.btc.bl.internal.services;

import java.util.List;

import org.osgi.service.component.annotations.Component;

import com.btc.bl.dmos.Requirement;
import com.btc.bl.internal.dmos.RequirementImpl;
import com.btc.bl.services.RequirementService;

@Component
public class RequirementServiceImpl implements RequirementService {

	@Override
	public void create(String name, String description) {
		
		Requirement requirement = new RequirementImpl(name, description);
		System.out.println("Creating requirement...");
	}

	@Override
	public List<Requirement> getAll() {
		
		
		return null;
	}

	
}
