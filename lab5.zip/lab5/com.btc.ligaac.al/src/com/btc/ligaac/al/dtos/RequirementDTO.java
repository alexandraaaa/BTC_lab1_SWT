package com.btc.ligaac.al.dtos;

public interface RequirementDTO {

	String getName();
	String getDescription();
}
