package com.btc.ligaac.al.services;

public interface RequirementApplicationService {
		void create(String name, String description);
}
