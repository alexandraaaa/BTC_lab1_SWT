package com.btc.ligaac.al.dtos;

public class RequirementDTOImpl implements RequirementDTO {
	
	public RequirementDTOImpl(String name, String description) {
		this.name = name;
		this.description = description;
	}
	private String name, description;
	
	

	public String getName() {
			return name;
	}
	public String getDescription() {
			return description;
	}
}
