package com.btc.ligaac.al.services;

public class RequirementApplicationServiceImpl implements RequirementApplicationService {
		public void create(String name, String description) {
			
			
		}
}
