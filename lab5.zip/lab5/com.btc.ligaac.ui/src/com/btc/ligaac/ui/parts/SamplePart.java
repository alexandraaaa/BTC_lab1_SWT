package com.btc.ligaac.ui.parts;

import java.util.Arrays;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.ui.MDirtyable;
import org.eclipse.jface.layout.GridDataFactory;
import org.eclipse.jface.layout.GridLayoutFactory;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import com.btc.ligaac.wizards.AddRequirementWizard;

public class SamplePart {

	private Text txtInput;
	private TableViewer tableViewer;

	@Inject
	private AddRequirementWizard requirementWizard;	//varianta fara new, folosesc adnotarile @Inject si @Creatable
	
	@Inject
	private MDirtyable dirty;

	@PostConstruct
	public void createComposite(Composite parent) {
		GridLayoutFactory.swtDefaults().numColumns(10).applyTo(parent);

		txtInput = new Text(parent, SWT.BORDER);
		txtInput.setMessage("Enter text to mark part as dirty");
		txtInput.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				dirty.setDirty(true);
			}
		});
		GridDataFactory.swtDefaults().span(10, GridData.FILL).applyTo(txtInput);

		tableViewer = new TableViewer(parent);

		tableViewer.setContentProvider(ArrayContentProvider.getInstance());;
		tableViewer.setInput(createInitialDataModel());
		//tableViewer.getTable().setLayoutData(new GridData(GridData.FILL_BOTH));
		GridDataFactory.swtDefaults().span(10, 1).applyTo(tableViewer.getTable());
		
		Button addButton = new Button(parent, SWT.BORDER);
		addButton.setText("Add");
		GridDataFactory.swtDefaults().span(5, 1).applyTo(addButton);
		
		addButton.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				//AddRequirementWizard requirementWizard = new AddRequirementWizard(); 		//varianta cu new
				WizardDialog wizardDialog = new WizardDialog(parent.getShell(), requirementWizard);
				wizardDialog.open();
			}
			 
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				
				
			}
		});
		
		Button refreshButton = new Button(parent, SWT.BORDER);
		refreshButton.setText("Refresh");
		GridDataFactory.swtDefaults().span(5, 1).applyTo(refreshButton);
		
		refreshButton.addSelectionListener(new SelectionListener() {
			
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				
				
			}
		});
	}

	@Focus
	public void setFocus() {
		tableViewer.getTable().setFocus();
	}

	@Persist
	public void save() {
		dirty.setDirty(false);
	}
	
	private List<String> createInitialDataModel() {
		return Arrays.asList("Sample item 1", "Sample item 2", "Sample item 3", "Sample item 4", "Sample item 5");
	}
}