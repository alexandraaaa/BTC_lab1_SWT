package com.btc.ligaac.wizards;

import org.eclipse.jface.wizard.WizardPage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

public class AddRequierementWizardPage extends WizardPage {
	
	private Text textName ;
	private Text textDescription ;

	protected AddRequierementWizardPage(String pageName) {
		super(pageName);
		setTitle(pageName);
	}

	@Override
	public void createControl(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		container.setLayout(new GridLayout());
		
		textName = new Text(container, SWT.NONE);
		textDescription= new Text(container, SWT.NONE);
		
		setControl(container);
	}
	
	public String getName() {
		return textName.getText();
	}
	
	public String getDescription() {
		
		return textDescription.getText();
	}
}
