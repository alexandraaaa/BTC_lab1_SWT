package com.btc.ligaac.wizards;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.jface.wizard.Wizard;

@Creatable		//sa poate fi folosita varianta fara new
public class AddRequirementWizard extends Wizard {

	private AddRequierementWizardPage page;
	@Override
	public void addPages() {
		page = new AddRequierementWizardPage("Add requirement");
		addPage(page);
	}
	
	@Override
	public boolean performFinish() {
		//System.out.println("Requirement {name : " + page.getName() + "}");
		return true;	//true ca sa se inchida fereastra
	}

}
