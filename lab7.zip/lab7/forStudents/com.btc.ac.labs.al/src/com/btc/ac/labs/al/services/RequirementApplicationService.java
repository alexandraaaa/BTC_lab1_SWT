package com.btc.ac.labs.al.services;

import java.util.List;
import java.util.UUID;

import com.btc.ac.labs.al.dtos.RequirementDTO;

public interface RequirementApplicationService {
	void saveRequirement(String name, String description);

	RequirementDTO updateRequirement(RequirementDTO requirementDTO);

	void removeRequirement(long id);
	
	List<RequirementDTO> getAll();
	
	List<RequirementDTO> getMatching(String match);
}
