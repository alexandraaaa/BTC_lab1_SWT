package com.btc.ac.labs.bl.internal.dmos;

import java.io.Serializable;

import com.btc.ac.labs.bl.dmos.RequirementDMO;

public class RequirementDMOImpl implements RequirementDMO, Serializable {

	private static final long serialVersionUID = -5115336796815788110L;

	private long id;
	private String name;
	private String description;

	public RequirementDMOImpl(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public RequirementDMOImpl(long id, String name, String description) {
		this.id = id;
		this.name = name;
		this.description = description;
	}

	@Override
	public long getId() {
		return id;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}
}
