package com.btc.ac.labs.ui.parts;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.e4.core.di.annotations.Optional;
import org.eclipse.e4.ui.di.Focus;
import org.eclipse.e4.ui.di.Persist;
import org.eclipse.e4.ui.model.application.ui.MDirtyable;
import org.eclipse.e4.ui.model.application.ui.basic.MPart;
import org.eclipse.e4.ui.services.IServiceConstants;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.window.Window;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.al.services.RequirementApplicationService;
import com.btc.ac.labs.ui.wizards.CreateRequirementWizard;

@Creatable
public class NavigationPart {

	private Text txtInput;
	private TableViewer tableViewer;

	@Inject
	private MDirtyable dirty;

	@Inject
	private CreateRequirementWizard createRequirementWizard;

	@Inject
	private RequirementApplicationService requirementApplicationService;

	@Inject
	@Optional
	public void receiveActivePart(@Named(IServiceConstants.ACTIVE_PART) MPart activePart) {
		if (activePart != null) {
			System.out.println("Active part changed " + activePart.getLabel());
		}
	}

	// tracks the active shell
	@Inject
	@Optional
	public void receiveActiveShell(@Named(IServiceConstants.ACTIVE_SHELL) Shell shell) {
		if (shell != null) {
			System.out.println("Active shell (Window) changed");
		}
	}

	@PostConstruct
	public void createComposite(Composite parent) {
		parent.setLayout(new GridLayout(1, false));

		txtInput = new Text(parent, SWT.BORDER);
		txtInput.setMessage("Search requirement");
		txtInput.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				if (txtInput.getText().isEmpty()) {
					tableViewer.setInput(getAllRequirements());
					return;
				}
				List<RequirementDTO> requirements = requirementApplicationService.getMatching(txtInput.getText());
				List<String> requirementNames = requirements.stream().map(r -> r.getName())
						.collect(Collectors.toList());

				tableViewer.setInput(requirementNames);
			}
		});
		txtInput.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		tableViewer = new TableViewer(parent);

		tableViewer.setContentProvider(ArrayContentProvider.getInstance());

		tableViewer.setInput(getAllRequirements());
		tableViewer.getTable().setLayoutData(new GridData(GridData.FILL_BOTH));
		tableViewer.addSelectionChangedListener(new ISelectionChangedListener() {

			@Override
			public void selectionChanged(SelectionChangedEvent event) {
				RequirementDTO requirementDTO = (RequirementDTO) ((StructuredSelection) tableViewer.getSelection())
						.getFirstElement();
				if (requirementDTO.getName() == null || requirementDTO.getDescription() == null) {
					return;
				}

				DashboardPart.setName(requirementDTO.getName());

				DashboardPart.setDescription(requirementDTO.getDescription());
			}

		});

		Menu contextMenu = new Menu(tableViewer.getTable());
		tableViewer.getTable().setMenu(contextMenu);
		MenuItem mItem1 = new MenuItem(contextMenu, SWT.None);
		mItem1.setText("Remove requirement");
		mItem1.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				RequirementDTO requirementDTO = (RequirementDTO) ((StructuredSelection) tableViewer.getSelection())
						.getFirstElement();

				requirementApplicationService.removeRequirement(requirementDTO.getId());
				tableViewer.setInput(getAllRequirements());
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		tableViewer.getTable().addListener(SWT.MouseDown, new Listener() {

			@Override
			public void handleEvent(Event event) {
				TableItem[] selection = tableViewer.getTable().getSelection();
				if (selection.length != 0 && (event.button == 3)) {
					contextMenu.setVisible(true);
				}

			}
		});

		Button button = new Button(parent, SWT.PUSH);
		button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		button.setText("Add requirement");
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				WizardDialog wizardDialog = new WizardDialog(parent.getShell(), createRequirementWizard);
				if (wizardDialog.open() == Window.OK) {
					System.out.println("Ok pressed");
					tableViewer.setInput(getAllRequirements());
				} else {
					System.out.println("Cancel pressed");
				}
			}
		});

	}

	@Focus
	public void setFocus() {
		tableViewer.getTable().setFocus();
	}

	@Persist
	public void save() {
		dirty.setDirty(false);
	}

	private List<RequirementDTO> getAllRequirements() {
		return requirementApplicationService.getAll().stream().filter(r -> r.getName() != null)
				.collect(Collectors.toList());
	}
}