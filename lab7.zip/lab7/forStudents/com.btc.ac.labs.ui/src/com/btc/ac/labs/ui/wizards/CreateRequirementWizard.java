package com.btc.ac.labs.ui.wizards;

import javax.inject.Inject;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.jface.wizard.Wizard;

import com.btc.ac.labs.al.services.RequirementApplicationService;

@Creatable
public class CreateRequirementWizard extends Wizard {

	@Inject
	private CreateRequirementWizardPage page;
	
	@Inject
	private RequirementApplicationService requirementApplicationService;

	private boolean pagesAdded;
	
	@Override
	public String getWindowTitle() {
		return "Create New Requirement";
	}

	@Override
	public void addPages() {
		if (pagesAdded) return;
		
		addPage(page);
		pagesAdded = true;
	}

	@Override
	public boolean performFinish() {

		requirementApplicationService.saveRequirement(page.getName(), page.getDescription());

		return true;
	}

}
