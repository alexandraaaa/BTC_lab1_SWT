package com.btc.ac.labs.ui.parts;


import javax.annotation.PostConstruct;

import org.eclipse.e4.core.di.annotations.Creatable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;

@Creatable
public class DashboardPart {

	private Label lblName;
	private static Text txtName;
	private Label lblDescription;
	private static Text txtDescription;
	
	@PostConstruct
	public void createComposite(Composite parent) {
		parent.setLayout(new GridLayout());
		
		GridData dataAllFill =  new GridData();
		dataAllFill.horizontalAlignment = SWT.FILL;
		dataAllFill.grabExcessHorizontalSpace = true;
		dataAllFill.verticalAlignment = SWT.FILL;
		dataAllFill.grabExcessVerticalSpace = true;
		
		GridData dataHorisontalFill =  new GridData();
		dataHorisontalFill.horizontalAlignment = SWT.FILL;
		dataHorisontalFill.grabExcessHorizontalSpace = true;
		
		Group group = new Group(parent, SWT.NONE);
		group.setText("Requirement details");
		group.setLayout(new GridLayout());
		group.setLayoutData(dataAllFill);
		
		lblName = new Label(group, SWT.NONE);
		lblName.setText("Name:");
		
		txtName = new Text(group, SWT.BORDER);
		txtName.setText("N/A");
		txtName.setEditable(false);
		txtName.setLayoutData(dataHorisontalFill);
		
		lblDescription = new Label(group, SWT.NONE);
		lblDescription.setText("Description:");
		
		txtDescription = new Text(group, SWT.BORDER);
		txtDescription.setText("N/A");
		txtDescription.setEditable(false);
		txtDescription.setLayoutData(dataHorisontalFill);
		
	}
	
	public static void setName(String name) {
		txtName.setText(name);
	}
	
	public static void setDescription(String description) {
		txtDescription.setText(description);
	}
}
