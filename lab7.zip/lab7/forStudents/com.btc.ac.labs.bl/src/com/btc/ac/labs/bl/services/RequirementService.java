package com.btc.ac.labs.bl.services;

import java.util.Collection;
import java.util.List;

import com.btc.ac.labs.bl.dmos.RequirementDMO;

public interface RequirementService {
	void saveRequirement(String name, String description);

	void updateRequirement(RequirementDMO requirementDMO);

	void removeRequirement(long id);
	
	RequirementDMO get(long id);
	
	List<RequirementDMO> getAll();

	List<RequirementDMO> getMatching(String match);
}
