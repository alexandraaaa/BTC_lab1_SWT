package com.btc.al.labs.al.internal.factories;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.btc.ac.labs.al.dtos.RequirementDTO;

public class RequirementDTOFactoryImpl_UT {

	private RequirementDTOFactoryImpl sut;
	
	@Before
	public void setUP() {
		
		sut = new RequirementDTOFactoryImpl();
	}
	
	@Test
	public void create() {
		
		String name = "gigel";
		String description = "mecanic";
		
		RequirementDTO requirementDTO = sut.create(name, description);
		
		assertEquals("Unexpected name", name, requirementDTO.getName());
		assertEquals("Unexpected description", description, requirementDTO.getDescription());
	}
}
