package com.btc.ac.labs.al.internal.services;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.al.internal.converters.RequirementConverter;
import com.btc.ac.labs.bl.dmos.RequirementDMO;
import com.btc.ac.labs.bl.services.RequirementService;

public class RequirementApplicationServiceImpl_UT {

	private RequirementApplicationServiceImpl sut;
	private RequirementService requirementService;
	
	@Before
	public void setUp() {
		sut = new RequirementApplicationServiceImpl();
		
		requirementService = Mockito.mock(RequirementService.class);
		
		sut.setRequirementService(requirementService);
	}
	
	@Test
	public void saveRequirement() {
		
		String name = "gigel";
		String description = "mecanic";
		
		sut.saveRequirement(name, description);
		
		Mockito.verify(requirementService).saveRequirement(name, description);				//verify verifica ca s-a apelat cel putin o data metoda	
	}
	
	@Test
	public void updateRequirement() {
		
		RequirementDMO dmo = Mockito.mock(RequirementDMO.class);
		RequirementDTO dto = Mockito.mock(RequirementDTO.class);
		RequirementDTO requirementDTO = Mockito.mock(RequirementDTO.class);
		
		RequirementConverter requirementFactory = Mockito.mock(RequirementConverter.class);
		
		when(requirementFactory.createRequirementDMO(requirementDTO).);
		
		
		Mockito.verify(requirementService).updateRequirement(dmo);
	}
}
