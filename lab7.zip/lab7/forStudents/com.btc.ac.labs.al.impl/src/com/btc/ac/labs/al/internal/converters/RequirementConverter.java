package com.btc.ac.labs.al.internal.converters;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.bl.dmos.RequirementDMO;

public interface RequirementConverter {
	public RequirementDMO createRequirementDMO(RequirementDTO requirementDTO);

	public RequirementDTO createRequirementDTO(RequirementDMO requirementDMO);
}
