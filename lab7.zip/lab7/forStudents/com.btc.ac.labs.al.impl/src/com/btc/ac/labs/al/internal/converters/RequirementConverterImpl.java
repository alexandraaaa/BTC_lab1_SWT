package com.btc.ac.labs.al.internal.converters;

import org.osgi.service.component.annotations.Component;

import com.btc.ac.labs.al.dtos.RequirementDTO;
import com.btc.ac.labs.al.internal.dtos.RequirementDTOImpl;
import com.btc.ac.labs.bl.dmos.RequirementDMO;
import com.btc.ac.labs.bl.internal.dmos.RequirementDMOImpl;

@Component
public class RequirementConverterImpl implements RequirementConverter{

	@Override
	public RequirementDMO createRequirementDMO(RequirementDTO requirementDTO) {
		return new RequirementDMOImpl(requirementDTO.getId(), requirementDTO.getName(), requirementDTO.getDescription());
	}

	@Override
	public RequirementDTO createRequirementDTO(RequirementDMO requirementDMO) {
		return new RequirementDTOImpl(requirementDMO.getId(), requirementDMO.getName(), requirementDMO.getDescription());
	}

}
