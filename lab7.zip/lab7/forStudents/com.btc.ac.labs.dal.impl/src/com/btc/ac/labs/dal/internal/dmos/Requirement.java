package com.btc.ac.labs.dal.internal.dmos;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.btc.ac.labs.bl.dmos.RequirementDMO;

@Entity
public class Requirement implements Serializable {

	private static final long serialVersionUID = -5115336796815788110L;

	@Id
	@GeneratedValue
	private long id;
	private String name;
	private String description;

	public Requirement(String name, String description) {
		this.name = name;
		this.description = description;
	}
	
	public Requirement(RequirementDMO dmo) {
		this.id = dmo.getId();
		this.name = dmo.getName();
		this.description = dmo.getDescription();
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}