package com.btc.ac.labs.dal.internal.utility;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import com.btc.ac.labs.dal.internal.dmos.Requirement;

public class PersistenceUtility {
	private static EntityManagerFactory emf;
	private static EntityManager entityManager;
	private static PersistenceUtility instance;

	private PersistenceUtility() {
		try {
			emf = Persistence.createEntityManagerFactory("$objectdb/db/requirements.odb");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static PersistenceUtility getInstance() {
		if (instance == null) {
			instance = new PersistenceUtility();
		}

		entityManager = emf.createEntityManager();

		return instance;
	}

	@PersistenceUnit
	public void setEntityManager(EntityManagerFactory emf) {
		this.emf = emf;
	}

	public Requirement get(long id) {
		TypedQuery<Requirement> query = entityManager.createQuery("SELECT r FROM Requirement r WHERE r.id = :id",
				Requirement.class);
		query.setParameter("id", id);

		return query.getSingleResult();
	}

	public List<Requirement> getAll() {
		TypedQuery<Requirement> query = entityManager.createQuery("SELECT r FROM Requirement r", Requirement.class);

		return query.getResultList();
	}

	public List<Requirement> getMatching(String match) {
		TypedQuery<Requirement> query = entityManager.createQuery("SELECT r FROM Requirement r WHERE r.name LIKE :match", Requirement.class);
		query.setParameter("match", "%" + match + "%");

		return query.getResultList();
	}

	public void create(Requirement dmo) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(dmo);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();

			entityManager.getTransaction().rollback();
		} finally {
			entityManager.close();
		}
	}

	public void update(Requirement dmo) {
		try {
			Requirement result = entityManager.find(Requirement.class, dmo.getId());

			entityManager.getTransaction().begin();
			result.setName(dmo.getName());
			result.setDescription(dmo.getDescription());
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			entityManager.getTransaction().rollback();
		} finally {
			entityManager.close();
		}
	}

	public void remove(long id) {
		try {
			TypedQuery<Requirement> query = entityManager.createQuery("SELECT r FROM Requirement r WHERE r.id = :id",
					Requirement.class);
			query.setParameter("id", id);

			Requirement result = query.getSingleResult();

			entityManager.getTransaction().begin();
			entityManager.remove(result);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			entityManager.getTransaction().rollback();
		} finally {
			entityManager.close();
		}
	}
}
